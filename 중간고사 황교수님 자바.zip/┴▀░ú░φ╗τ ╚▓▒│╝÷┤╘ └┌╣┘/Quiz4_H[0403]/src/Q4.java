import java.util.Arrays;

public class Q4 {
	public static void main(String[] args) {
	int [][] res = new int[8][9];
	
	for(int i=0; i<res.length;i++) {
		for(int j=0; j<res.length+1; j++) {
			res[i][j] = (i+2)*(j+1);
		}
	}
		System.out.print(Arrays.deepToString(res));
	
//	for(int i=0; i<res.length;i++) {
//		for(int j=0; j<res.length+1; j++) {
//			System.out.println(res[i][j] + " ");
//		}
//		System.out.println();
//	}
	}
}

