import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) {
		Solution s = new Solution();
		int [] arr = {1, 2, 3, 4, 5, 7, 7};
		System.out.println(s.solution(arr,7));
	}
}	
