import java.util.Random;

public class Q3 {
	public static void main(String[] args) {
		//랜덤 선택정렬
		Random random = new Random();
		int[] arr = new int[20];
		
		for(int i=0; i<arr.length;i++) {
			int minValue = i;
			for(int j=i+1; j<arr.length-1;j++) {
				if(arr[i] >= minValue){
					arr[i] =minValue;
				}
				minValue = i;
				int temp = arr[i];
				arr[i] = minValue;
				minValue = temp;
			}
		}
		for(int i=0; i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		
	}
}
