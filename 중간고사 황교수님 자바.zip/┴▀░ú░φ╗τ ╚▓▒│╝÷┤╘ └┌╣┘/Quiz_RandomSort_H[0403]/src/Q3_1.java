import java.util.Random;

public class Q3_1 {
	public static void main(String[] args) {
		Random random = new Random();
		int [] arr = new int[20];
		
		for(int i=0; i<arr.length;i++) {
			int minValueIndex = i;
			for(int j=i+1; j<arr.length-1;j++) {
				if(arr[i] >= minValueIndex) {
					arr[i] = minValueIndex;
				}
				int temp = arr[i];
				arr[i] = minValueIndex;
				minValueIndex = temp;
			}
		}
		for(int i=0; i<arr.length;i++) {
			System.out.println(arr[i]);
		}
	}
}
