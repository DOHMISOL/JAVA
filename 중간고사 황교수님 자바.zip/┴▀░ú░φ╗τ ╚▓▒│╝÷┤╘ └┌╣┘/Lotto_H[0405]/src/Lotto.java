import java.util.Random;

public class Lotto {
	public static void main(String[] args) {
		//1~45 중의 숫자 중 6개를 랜덤하게 뽑는 프로그램을 작성하시오. 중복된 숫자를 제거하는 로직이 포함되어야 함.
	Random random = new Random();
			
			int[] number = new int[6];
			
			for(int i=0; i<number.length;i++) {
				number[i] = random.nextInt(45)+1;
			}
			
			for(int i=0;i<number.length;i++) {
				for(int j =0; j<i;j++) {
					if(number[i] == number[j]) {
						i--;
						break;
					}
				}
				System.out.println("출력된 랜덤 로또번호는 " + number[i] + "입니다.");
			}
	}
}

