
public class MainClass {
	public static void main(String[] args) {
		
		Solution s = new Solution();
		double result = s.solution(144, 11);
		System.out.println(result);
	}
}
