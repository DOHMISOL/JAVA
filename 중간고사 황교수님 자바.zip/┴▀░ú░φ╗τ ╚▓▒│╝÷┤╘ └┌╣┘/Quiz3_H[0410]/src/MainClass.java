import java.util.Arrays;

public class MainClass {
	public static void main(String[] args) {
		Solution s = new Solution();
		int [] asdf = {4,8,6,9,5};
		System.out.println(Arrays.toString(s.solution(asdf)));
	}
}
