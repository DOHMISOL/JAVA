
public class MainClass {
	public static void main(String[] args) {
//		Solution s = new Solution();
//		s.solution();
	}
}
