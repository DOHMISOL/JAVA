
public class Practice1234 {

}
