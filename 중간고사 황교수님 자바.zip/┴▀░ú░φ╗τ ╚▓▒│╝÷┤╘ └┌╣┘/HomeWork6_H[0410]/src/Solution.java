
public class Solution {
	public int[] solution(int[] array, int[][] commands) {
		int[] answer = {};
		return answer;
	}
}
