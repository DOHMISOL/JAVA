
public class MainClass {
	public static void main(String[] args) {
		Solution s = new Solution();
		String asdf = s.solution(5);
		System.out.println(asdf);
	}
}
