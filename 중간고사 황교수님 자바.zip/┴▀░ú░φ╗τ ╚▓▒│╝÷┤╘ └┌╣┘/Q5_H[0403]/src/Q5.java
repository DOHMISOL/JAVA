import java.util.Arrays;

public class Q5 {
	public static void main(String[] args) {
		
		int arr[][] = {{10,33,44},{27,5,98}};
		
		int sum = 0;
		for(int i=0;i<2;i++) {
			for(int j=0; j<3;j++) {
				sum = sum + arr[i][j];
			}
		}
		System.out.println(sum);
	}
}