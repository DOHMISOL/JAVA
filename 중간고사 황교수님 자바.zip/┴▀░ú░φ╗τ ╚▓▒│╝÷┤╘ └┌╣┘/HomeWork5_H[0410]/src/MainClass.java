
public class MainClass {
	public static void main(String[] args) {
		
		Solution s = new Solution();
		int result = s.solution(6);
		System.out.println(result);
	}
}
