import java.util.Arrays;

public class Q2 {
	public static int solution(String s) {
		int a  = Integer.parseInt(s);
		int answer = a;
		return answer; 
	}
}
