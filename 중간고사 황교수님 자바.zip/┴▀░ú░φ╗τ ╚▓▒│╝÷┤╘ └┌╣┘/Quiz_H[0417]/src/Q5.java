
public class Q5 {
	
	public String solution(int n) {
	        String answer = "";
	        
	        for(int i=0; i<)
	        
	        return answer;
	    }
	
}
