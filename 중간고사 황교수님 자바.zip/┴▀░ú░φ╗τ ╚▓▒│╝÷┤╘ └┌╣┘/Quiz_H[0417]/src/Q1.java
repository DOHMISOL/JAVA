
public class Q1 {
	public static void main(String[] args) { 
		
	}
}
