import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		
		PurchaseOrder purchaseOrder = new PurchaseOrder();
		ProductList productList = new ProductList();
		
		for (int i = 0; i < 999999; i++) {
			System.out.println("---------전체메뉴선택--------");
			System.out.println("1. 상품등록 2. 상품목록 출력 3. 상품 통계 4.상품정렬 5.상품구매  q.종료");

			String InputString = scanner.nextLine();

			if (InputString.equals("q")) {
				break;
			} else if (InputString.equals("1")) {
				productList.addProduct();
			} else if (InputString.equals("2")) {
				productList.printProductList();
			} else if (InputString.equals("3")) {
				productList.showStatistics();
			} else if (InputString.equals("4")) {
				productList.sortProduct();
			} else if (InputString.equals("5")) {
				purchaseOrder.buyProduct();
			} else {
				System.out.println("잘못된 입력입니다. 다시 입력해주세요.");
			}
		}
	}
}
