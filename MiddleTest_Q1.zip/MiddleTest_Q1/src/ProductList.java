import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class ProductList extends ArrayList<Product> {
//	상품 등록 및 목록 조회 기능
	public ArrayList<Product> productList;

	public ProductList() {
		productList = new ArrayList<>();
	}
	public ArrayList<Product> getProductList() {
		return productList;
	}

	public void addProduct() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("상품명을 입력하세요: ");
		String name = scanner.nextLine();
		System.out.print("가격을 입력하세요: ");
		int price = Integer.parseInt(scanner.nextLine());
		System.out.print("재고를 입력하세요: ");
		int stock = Integer.parseInt(scanner.nextLine());
		System.out.print("할인율을 입력하세요(소수점 입력): ");
		double discountRate = Double.parseDouble(scanner.nextLine());
		Product product = new Product(name, price, stock, discountRate);
		productList.add(product);
		System.out.println("상품이 등록되었습니다.");
	}

	public void printProductList() {
		if (productList.isEmpty()) {
			System.out.println("등록된 상품이 없습니다.");
		} else {
			for (Product product : productList) {
				product.printInfo();
			}
		}
	}

	public void showStatistics() {
		int totalProducts = productList.size();
		double totalPrices = 0.0;

		for (Product product : productList) {
			totalPrices += product.getPrice();
		}

		double averagePrice = totalPrices / totalProducts;
		System.out.println();
		System.out.println("총 상품 수: " + totalProducts + "입니다.");
		System.out.println("평균 가격: " + averagePrice + "입니다.");
		System.out.println();
	}

	public void sortProduct() {
		System.out.println("원하시는 정렬메뉴를 선택해주세요. q. 종료");
		System.out.println("1. 높은 가격순 2. 낮은 가격순 3. 할인율 높은순 4. 할인율 낮은순");
		Scanner scanner = new Scanner(System.in);
		String inputString = scanner.nextLine();
		if (inputString.equals("1")) {
			Collections.sort(productList, Comparator.comparing(Product::getPrice).reversed());
		} else if (inputString.equals("2")) {
			Collections.sort(productList, Comparator.comparing(Product::getPrice));
		} else if (inputString.equals("3")) {
			Collections.sort(productList, Comparator.comparing(Product::getPrice).reversed());
		} else if (inputString.equals("4")) {
			Collections.sort(productList, Comparator.comparing(Product::getDiscountRate));
		}
		System.out.println("제품 리스트가 정렬되었습니다.");
		printProductList();
	}
}
