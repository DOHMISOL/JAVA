
public class Product {

	private String name;
	private int price;
	private int stock;
	private double discountRate;
	private boolean isSoldOut;

	public Product(String name, int price, int stock, double discountRate) {
		this.name = name;
		this.price = price;
		this.stock = stock;
		this.discountRate = discountRate;
		this.isSoldOut = false;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public double getDiscountRate() {
		return discountRate;
	}

	public boolean isSoldOut() {
		return isSoldOut;
	}

	public void reduceStock() {
		if (stock > 0) {
			stock--;
			if (stock == 0) {
				isSoldOut = true;
			}
		}
	}

	public void increasePrice(int amount) {
		int increasedPrice = (int) Math.ceil((price + amount) / 10) * 10;
		price = increasedPrice;
	}

	public void printInfo() {
		System.out.println("상품명: " + name);
		System.out.println("가격: " + price + "원");
		System.out.println("재고: " + stock + "개");
		System.out.println("할인율: " + discountRate + "%");
		System.out.println();
	}
}
