import java.util.ArrayList;
import java.util.Scanner;

public class PurchaseOrder {
	
	private String productName;
	private int price;
	private String buyerName;
	private String buyerPhoneNum;
	private String deliveryAddress;
	ProductList productList = new ProductList();
	private ArrayList<PurchaseOrder> purchaseOrderList;

	public PurchaseOrder(String productName, int price, String buyerName, String buyerPhoneNum, String deliveryAddress) {
		this.productName = productName;
		this.price = price;
		this.buyerName = buyerName;
		this.buyerPhoneNum = buyerPhoneNum;
		this.deliveryAddress = deliveryAddress;
	}

	public String getProductName() {
		return productName;
	}

	public int getPrice() {
		return price;
	}

	public String getBuyerName() {
		return buyerName;
	}

	public String getBuyerPhoneNum() {
		return buyerPhoneNum;
	}

	public String getDeliveryAddress() {
		return deliveryAddress;
	}

	public void setBuyerPhoneNum(String phoneNum) {
		this.buyerPhoneNum = phoneNum;
	}

	public void setDeliveryAddress(String address) {
		this.deliveryAddress = address;
	}

	public void buyProduct() {
		System.out.println("구매 가능한 상품 목록입니다.");
		productList.printProductList();
		
		System.out.println("**상품구매는 1회 1품목 1개만 가능합니다.**");
		Scanner scanner = new Scanner(System.in);
		System.out.println("상품번호를 입력해주세요.");
		int productIndex = scanner.nextInt() - 1;

		Product selectedProduct = productList.get(productIndex);
		String productName = selectedProduct.getName();
		int price = selectedProduct.getPrice();
		double discountRate = selectedProduct.getDiscountRate();
		int discountedPrice = (int) (price * (1 - discountRate));

		System.out.println("구매할 상품 정보입니다.");
		System.out.println("상품명: " + productName);
		System.out.println("판매가: " + discountedPrice + "원");
		System.out.println("구매자 이름을 입력해주세요: ");
		String buyerName = scanner.next();
		System.out.println("구매자 연락처를 입력해주세요: ");
		String buyerPhoneNum = scanner.next();
		System.out.println("배송지 주소를 입력해주세요: ");
		String deliveryAddress = scanner.next();

		PurchaseOrder purchaseOrder = new PurchaseOrder(productName, discountedPrice, buyerName, buyerPhoneNum,
				deliveryAddress);
		purchaseOrderList.add(purchaseOrder);

		selectedProduct.reduceStock();

		System.out.println("상품이 구매되었습니다. 감사합니다!");

	}
}
